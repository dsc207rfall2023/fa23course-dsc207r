OK_FORMAT = True

test = {   'name': 'q4',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> expected_x = np.array([[18, 22, 16, 27, 31], [22, 14, 12, 19, 11], [17, 25, 17, 29, 25]])\n>>> np.testing.assert_equal(x, expected_x)\n',
                                       'hidden': True,
                                       'locked': False},
                                   {'code': '>>> assert answer == False\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
