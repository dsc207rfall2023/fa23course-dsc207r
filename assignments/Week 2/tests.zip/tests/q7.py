OK_FORMAT = True

test = {   'name': 'q7',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert np.array_equal(a[0], X[1]) and np.array_equal(a[1], X[0])\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert np.array_equal(X[1], Y[2]) and np.array_equal(X[2], Y[1])\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
