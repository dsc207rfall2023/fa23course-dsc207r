OK_FORMAT = True

test = {   'name': 'q5',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> expected_z = np.array([[18, 21, 14, 24, 27], [23, 14, 11, 17, 8], [19, 26, 17, 28, 23]])\n>>> np.testing.assert_equal(z, expected_z)\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
