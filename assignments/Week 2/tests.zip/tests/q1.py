OK_FORMAT = True

test = {   'name': 'q1',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> assert np.all(a >= 5)\n', 'hidden': True, 'locked': False}, {'code': '>>> assert np.all(a <= 26)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
