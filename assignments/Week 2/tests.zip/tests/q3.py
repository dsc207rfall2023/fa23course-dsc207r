OK_FORMAT = True

test = {   'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> answer1 = np.array([[15, 6], [25, 20]])\n'
                                               '>>> answer2 = np.array([[21, 12, 9, 15, 6], [16, 23, 14, 25, 20]])\n'
                                               '>>> np.testing.assert_equal(d, answer2) and np.testing.assert_equal(c, answer1)\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
