OK_FORMAT = True

test = {   'name': 'q6',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> answer = np.array([[-2.8, 0.2, -6.8, 3.2, 6.2], [8.4, -0.6, -3.6, 2.4, -6.6], [-3.6, 3.4, -5.6, 5.4, 0.4]])\n'
                                               '>>> np.testing.assert_allclose(answer, a_norm)\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
