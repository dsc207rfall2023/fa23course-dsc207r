OK_FORMAT = True

test = {'name': 'q10', 'points': 0.5, 'suites': [{'cases': [{'code': '>>> assert maxRating == 5.0\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
