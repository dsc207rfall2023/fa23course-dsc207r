OK_FORMAT = True

test = {   'name': 'q8',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> booksByRowling = books.loc[books['authors'] == 'J.K. Rowling']\n>>> assert avg_Rowling_book_rating == booksByRowling['average_rating'].mean()\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
