OK_FORMAT = True

test = {'name': 'q5', 'points': 0.5, 'suites': [{'cases': [{'code': '>>> assert num_books == 11123\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
