OK_FORMAT = True

test = {   'name': 'q7',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> answer = books['average_rating'].mean()\n>>> assert answer == avg_book_rating\n", 'hidden': True, 'locked': False},
                                   {'code': '>>> assert total_rating_count == 4776638\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
