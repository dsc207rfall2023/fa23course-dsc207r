OK_FORMAT = True

test = {'name': 'q1', 'points': 0.5, 'suites': [{'cases': [{'code': '>>> assert len(books) == 11123\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
