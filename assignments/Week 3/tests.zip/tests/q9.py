OK_FORMAT = True

test = {'name': 'q9', 'points': 0.5, 'suites': [{'cases': [{'code': '>>> assert num_authors == 6639\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
