OK_FORMAT = True

test = {   'name': 'q3',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': ">>> assert books.index.name == 'bookID'\n", 'hidden': True, 'locked': False},
                                   {'code': ">>> assert 'bookID' not in books.columns\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
