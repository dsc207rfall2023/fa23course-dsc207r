OK_FORMAT = True

test = {   'name': 'q12',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> answer_df = books[(books['ratings_count'] > 2000) & (books['average_rating'] > 4.7)]\n>>> assert answer_df.equals(popularBooks)\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
