OK_FORMAT = True

test = {   'name': 'q6',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': '>>> assert not booksByTolkien.empty\n', 'hidden': True, 'locked': False},
                                   {'code': ">>> assert (booksByTolkien['authors'] == 'J.R.R. Tolkien').all()\n", 'hidden': True, 'locked': False},
                                   {'code': '>>> assert len(booksByTolkien) == 17\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
