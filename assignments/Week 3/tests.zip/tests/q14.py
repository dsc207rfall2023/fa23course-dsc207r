OK_FORMAT = True

test = {   'name': 'q14',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> answer = books.language_code.value_counts().head(7)\n>>> assert popularLang.equals(answer)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
