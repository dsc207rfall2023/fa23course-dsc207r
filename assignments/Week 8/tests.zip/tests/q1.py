OK_FORMAT = True

test = {   'name': 'q1',
    'points': 1.0,
    'suites': [   {   'cases': [   {'code': '>>> assert isinstance(conn, sqlite3.Connection)\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert isinstance(cursor, sqlite3.Cursor)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
