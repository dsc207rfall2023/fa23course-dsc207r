OK_FORMAT = True

test = {   'name': 'q12',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': '>>> assert isinstance(investment_regression, sklearn.linear_model._base.LinearRegression)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
