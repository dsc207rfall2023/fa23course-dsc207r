OK_FORMAT = True

test = {   'name': 'q10',
    'points': 1.0,
    'suites': [{'cases': [{'code': '>>> assert X_train.shape == (3708, 5)\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
