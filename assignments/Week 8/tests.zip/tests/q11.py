OK_FORMAT = True

test = {   'name': 'q11',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': '>>> assert X_train.shape == (3708, 5)\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert X_test.shape == (928, 5)\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert y_train.shape == (3708,)\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert y_test.shape == (928,)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
