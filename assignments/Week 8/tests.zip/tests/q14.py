OK_FORMAT = True

test = {   'name': 'q14',
    'points': 0.5,
    'suites': [{'cases': [{'code': '>>> assert rmse > 5 and rmse <= 6\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
