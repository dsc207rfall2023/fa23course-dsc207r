OK_FORMAT = True

test = {   'name': 'q7',
    'points': 0.5,
    'suites': [{'cases': [{'code': '>>> assert len(predictions_train) == 851\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
