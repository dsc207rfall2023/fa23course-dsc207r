OK_FORMAT = True

test = {   'name': 'q8',
    'points': 0.5,
    'suites': [{'cases': [{'code': '>>> assert len(predictions_test) == 213\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
