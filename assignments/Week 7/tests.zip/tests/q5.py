OK_FORMAT = True

test = {   'name': 'q5',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': '>>> assert X_train.shape == (851, 8)\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert X_test.shape == (213, 8)\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert y_train.shape == (851,)\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert y_test.shape == (213,)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
