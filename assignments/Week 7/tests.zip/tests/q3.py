OK_FORMAT = True

test = {   'name': 'q3',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': '>>> assert len(X) == 1064\n', 'hidden': True, 'locked': False}, {'code': '>>> assert len(y) == 1064\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
