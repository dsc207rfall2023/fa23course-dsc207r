OK_FORMAT = True

test = {   'name': 'q12',
    'points': 1.0,
    'suites': [{'cases': [{'code': '>>> assert isinstance(clf_2, RandomForestClassifier)\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
