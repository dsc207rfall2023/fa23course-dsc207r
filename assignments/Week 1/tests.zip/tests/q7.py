OK_FORMAT = True

test = {   'name': 'q7',
    'points': 15,
    'suites': [   {   'cases': [   {'code': '>>> assert fibonacci(1) == [0]\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert fibonacci(5) == [0, 1, 1, 2, 3]\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert fibonacci(0) == []\n', 'hidden': True, 'locked': False},
                                   {'code': '>>> assert fibonacci(10) == [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
