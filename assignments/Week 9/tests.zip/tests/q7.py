OK_FORMAT = True

test = {   'name': 'q7',
    'points': 0.5,
    'suites': [{'cases': [{'code': '>>> assert len(filtered_words) == 710579\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
