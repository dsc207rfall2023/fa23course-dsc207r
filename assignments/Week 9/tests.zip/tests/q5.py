OK_FORMAT = True

test = {   'name': 'q5',
    'points': 1.0,
    'suites': [   {   'cases': [   {   'code': '>>> ans_5 = {word: 1 for word in nltk.word_tokenize(romeo_text) if not word in useless_words}\n'
                                               ">>> assert ans_5.keys() == romeo_useful_word_dict.keys(), 'Dictionaries have different keys.'\n"
                                               ">>> assert all((ans_5[key] == romeo_useful_word_dict[key] for key in ans_5)), 'Dictionaries have the same keys but different values.'\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
