OK_FORMAT = True

test = {   'name': 'q5',
    'points': 1.0,
    'suites': [   {   'cases': [   {'code': '>>> assert type(build_bag_of_words_features_filtered(romeo_words)) == dict\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert len(romeo_useful_word_dict) == 31\n', 'hidden': False, 'locked': False},
                                   {   'code': '>>> ans_5 = build_bag_of_words_features_filtered(romeo_words)\n>>> assert sorted(ans_5) == sorted(romeo_useful_word_dict)\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
