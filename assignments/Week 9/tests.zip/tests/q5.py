OK_FORMAT = True

test = {   'name': 'q5',
    'points': 1.0,
    'suites': [   {   'cases': [   {   'code': '>>> romeo_words = nltk.word_tokenize(romeo_text)\n'
                                               '>>> ans_5 = {word: 1 for word in romeo_words if not word in useless_words}\n'
                                               '>>> assert sorted(ans_5) == sorted(romeo_useful_word_dict)\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
