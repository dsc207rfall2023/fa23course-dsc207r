OK_FORMAT = True

test = {   'name': 'q8',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': '>>> assert type(most_common_words) == list\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert len(most_common_words) == 10\n', 'hidden': False, 'locked': False},
                                   {   'code': ">>> assert most_common_words == [('film', 9517), ('one', 5852), ('movie', 5771), ('like', 3690), ('even', 2565), ('good', 2411), ('time', 2411), "
                                               "('story', 2169), ('would', 2109), ('much', 2049)]\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
