OK_FORMAT = True

test = {   'name': 'q1',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': '>>> assert type(romeo_tokens) == list\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert len(romeo_tokens) == 52\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> ans_1 = romeo_text.split()\n>>> assert sorted(ans_1) == sorted(romeo_tokens)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
