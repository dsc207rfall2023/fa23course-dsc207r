OK_FORMAT = True

test = {   'name': 'q1',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': '>>> ans_1 = romeo_text.split()\n>>> assert sorted(ans_1) == sorted(romeo_tokens)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
