OK_FORMAT = True

test = {   'name': 'q2',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': '>>> assert type(romeo_words) == list\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert len(romeo_words) == 68\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> ans_2 = nltk.word_tokenize(romeo_text)\n>>> assert sorted(ans_2) == sorted(romeo_words)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
