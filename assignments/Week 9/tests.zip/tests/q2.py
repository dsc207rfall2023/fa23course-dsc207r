OK_FORMAT = True

test = {   'name': 'q2',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': '>>> ans_2 = nltk.word_tokenize(romeo_text)\n>>> assert sorted(ans_2) == sorted(romeo_words)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
