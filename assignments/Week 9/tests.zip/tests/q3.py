OK_FORMAT = True

test = {   'name': 'q3',
    'points': 1.0,
    'suites': [   {   'cases': [   {   'code': '>>> romeo_words = nltk.word_tokenize(romeo_text)\n'
                                               '>>> ans_3 = {word: True for word in romeo_words}\n'
                                               '>>> assert sorted(ans_3) == sorted(romeo_word_dict)\n',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
