OK_FORMAT = True

test = {   'name': 'q3',
    'points': 1.0,
    'suites': [   {   'cases': [   {   'code': '>>> ans_3 = {word: True for word in nltk.word_tokenize(romeo_text)}\n'
                                               ">>> assert ans_3.keys() == romeo_word_dict.keys(), 'Dictionaries have different keys.'\n"
                                               ">>> assert all((ans_3[key] == romeo_word_dict[key] for key in ans_3)), 'Dictionaries have the same keys but different values.'\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
