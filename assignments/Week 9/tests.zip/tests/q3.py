OK_FORMAT = True

test = {   'name': 'q3',
    'points': 1.0,
    'suites': [   {   'cases': [   {'code': '>>> assert type(build_bag_of_words_features(romeo_words)) == dict\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert sum((value for value in romeo_word_dict.values() if value)) == 45\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> ans_3 = build_bag_of_words_features(romeo_words)\n>>> assert sorted(ans_3) == sorted(romeo_word_dict)\n', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
