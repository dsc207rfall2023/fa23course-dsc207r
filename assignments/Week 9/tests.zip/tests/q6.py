OK_FORMAT = True

test = {   'name': 'q6',
    'points': 0.5,
    'suites': [{'cases': [{'code': '>>> assert len(all_words) == 1583820\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
