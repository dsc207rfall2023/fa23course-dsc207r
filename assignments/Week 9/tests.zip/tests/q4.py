OK_FORMAT = True

test = {   'name': 'q4',
    'points': 0.5,
    'suites': [   {   'cases': [   {'code': '>>> assert type(useless_words) == list\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> assert len(useless_words) == 211\n', 'hidden': False, 'locked': False},
                                   {   'code': ">>> ans_4 = nltk.corpus.stopwords.words('english') + list(string.punctuation)\n>>> assert sorted(ans_4) == sorted(useless_words)\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
