OK_FORMAT = True

test = {   'name': 'q12',
    'points': 0.5,
    'suites': [   {   'cases': [{'code': ">>> answer = listings_df['neighbourhood'].value_counts()[:10]\n>>> assert top_10_neighbourhoods.equals(answer)\n", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
