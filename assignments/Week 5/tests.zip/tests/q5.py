OK_FORMAT = True

test = {'name': 'q5', 'points': 0.5, 'suites': [{'cases': [{'code': '>>> assert share_only_count == 73\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
