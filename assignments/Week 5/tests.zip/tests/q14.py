OK_FORMAT = True

test = {   'name': 'q14',
    'points': 0.5,
    'suites': [   {   'cases': [   {   'code': ">>> answer = listings_df[listings_df['neighbourhood'].isin(list(top_10_neighbourhoods.index))]\n>>> assert filtered_df.equals(answer)\n",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
