OK_FORMAT = True

test = {   'name': 'q2',
    'points': 0.5,
    'suites': [{'cases': [{'code': '>>> assert listings_size == (10301, 18)\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
