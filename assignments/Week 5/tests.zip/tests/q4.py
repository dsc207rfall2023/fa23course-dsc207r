OK_FORMAT = True

test = {   'name': 'q4',
    'points': 0.5,
    'suites': [{'cases': [{'code': ">>> assert unique_hosts == listings_df['host_id'].nunique()\n", 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
