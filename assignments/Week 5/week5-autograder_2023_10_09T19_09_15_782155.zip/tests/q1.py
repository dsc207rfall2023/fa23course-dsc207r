OK_FORMAT = True

test = {   'name': 'q1',
    'points': 0.5,
    'suites': [{'cases': [{'code': '>>> assert len(listings_df) == 10301\n', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
